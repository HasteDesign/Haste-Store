/*
 * Settings of the sticky menu
 */
    jQuery(window).load(function(){
      jQuery("#sticky_header").sticky({ topSpacing: 0 });
    });